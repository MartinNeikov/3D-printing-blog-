import { Link } from "react-router";

function Footer() {
  return (
    <footer className="site-footer">
      <div className="container">
        <div className="row">
          <div className="col-lg-4">
            <div className="widget">
              <h3 className="mb-4">About PrintForge</h3>

              <p>
                A community-driven 3D printing blog for sharing
                practical guides, printer knowledge, filament tips,
                print settings, and creative projects.
              </p>
            </div>
          </div>

          <div className="col-lg-4 ps-lg-5">
            <div className="widget">
              <h3 className="mb-4">Explore</h3>

              <ul className="list-unstyled links">
                <li>
                  <Link to="/">Home</Link>
                </li>

                <li>
                  <Link to="/articles">Articles</Link>
                </li>

                <li>
                  <Link to="/categories/3d-printers">
                    3D Printers
                  </Link>
                </li>

                <li>
                  <Link to="/categories/filaments">
                    Filaments
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="col-lg-4">
            <div className="widget">
              <h3 className="mb-4">Topics</h3>

              <ul className="list-unstyled links">
                <li>
                  <Link to="/categories/print-settings">
                    Print Settings
                  </Link>
                </li>

                <li>
                  <Link to="/categories/projects">
                    Projects
                  </Link>
                </li>

                <li>
                  <Link to="/articles/create">
                    Create Article
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="row mt-5">
          <div className="col-12 text-center">
            <p>
              © 2026 PrintForge. All Rights Reserved.
              {" — "}
              Designed with love by{" "}
              <a
                href="https://untree.co"
                target="_blank"
                rel="noreferrer"
              >
                Untree.co
              </a>
              {" — "}
              Distributed by{" "}
              <a
                href="https://themewagon.com"
                target="_blank"
                rel="noreferrer"
              >
                ThemeWagon
              </a>
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default Footer;